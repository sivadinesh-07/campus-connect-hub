import React from "react";
import "./Login.css";

const Login = () => {
  return (
    <div className="login-container">
      <div className="login-card">
        <div className="logo">CC</div>

        <h2>Welcome back</h2>
        <p className="subtitle">Sign in to Campus Connect Hub</p>

        <form>
          <div className="input-group">
            <label>Email</label>
            <input
              type="email"
              placeholder="you@university.edu"
              required
            />
          </div>

          <div className="input-group">
            <label>Password</label>
            <input
              type="password"
              placeholder="password"
              required
            />
          </div>

          <button type="submit" className="login-btn">
            <span>Sign In</span>
          </button>

          <div className="secure-box">
            🔒 Your session is secured with encrypted authentication.
          </div>

          <p className="signup-text">
            Don’t have an account? <a href="/signup">Sign up</a>
          </p>
        </form>
      </div>
    </div>
  );
};

export default Login;
